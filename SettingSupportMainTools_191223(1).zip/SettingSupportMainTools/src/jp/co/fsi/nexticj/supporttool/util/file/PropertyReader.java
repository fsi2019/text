package jp.co.fsi.nexticj.supporttool.util.file;

import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Properties;

public class PropertyReader {

	// クラス変数
	private final String path;		        // プロパティファイルパス
	private final Charset charset;			// 文字コード設定
	private Properties properties;			// プロパティ情報
	private final boolean isExistsFile;  // プロパティファイルが存在するか


	/**
	 * @return path
	 */
	public String getPath() {
		return path;
	}

	/**
	 * @return charset
	 */
	public Charset getCharset() {
		return charset;
	}

	/**
	 * @return isExistsFile
	 */
	public boolean isExistsFile() {
		return isExistsFile;
	}

	/**
	 * コンストラクタ, 文字コードはUTF-8
	 * @param filePath
	 */
	public PropertyReader(final String filePath) {
		this.path = filePath;
		this.charset = StandardCharsets.UTF_8;
		this.properties = new Properties();
		this.isExistsFile = loadProperty();
	}

	/**
	 * コンストラクタ, 文字コード指定あり
	 * @param filePath
	 * @param charset
	 */
	public PropertyReader(final String filePath, final Charset charset) {
		this.path = filePath;
		this.charset = charset;
		this.properties = new Properties();
		this.isExistsFile = loadProperty();
	}

	/**
	 * プロパティファイルの読み込み
	 */
	private boolean loadProperty() {
		try {
			properties.load(Files.newBufferedReader(Paths.get(path), charset));
			return true;
		} catch (IOException e) {
            // ファイル読み込みに失敗
            return false;
		}
	}

    /**
     * プロパティ値を取得する
     *
     * @param key キー
     * @return 値
     */
    public String getProperty(final String key) {
        return getProperty(key, "");
    }

    /**
     * プロパティ値を取得する
     *
     * @param key キー
     * @param defaultValue デフォルト値
     * @return キーが存在しない場合、デフォルト値
     *          存在する場合、値
     */
    public String getProperty(final String key, final String defaultValue) {
        return properties.getProperty(key, defaultValue);
    }
}
