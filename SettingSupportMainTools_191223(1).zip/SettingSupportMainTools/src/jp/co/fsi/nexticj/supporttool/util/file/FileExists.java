package jp.co.fsi.nexticj.supporttool.util.file;


import java.io.File;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;

/**
 * ファイルの存在チェック
 * @author keinakamu
 *
 */
public class FileExists {

	private FileExists() {}

	/**
	 * ファイルの存在チェック(存在すればOK)
	 * @param path
	 * @return
	 */
	public static boolean CheckExists(String filePath) {
		Path path = Paths.get(filePath);
		if( !path.toFile().exists() ) {
			System.out.println("[ERROR] " + filePath + " :ファイルが存在しません。");
			return false;
		}
		return true;
	}

	/**
	 * ファイルの存在チェック(存在しなければOK)
	 * @param filePath
	 * @return
	 */
	public static boolean CheckNotExists(String filePath) {
		try {
			Path path = Paths.get(filePath);
			File f = new File(filePath);
			Path parent = Paths.get(f.getCanonicalPath()).getParent();
			if( path.toFile().exists() ) {
					System.out.println("[ERROR] " + f.getCanonicalPath() + " :既にファイルが存在します。");
				return false;
			} else if( !parent.toFile().exists() ) {
				System.out.println("[ERROR] " + parent.toString() + " :フォルダが作成されていません。");
				return false;
			}
			return true;
		} catch (IOException e) {
			e.printStackTrace();
			System.out.println("[ERROR] " + filePath + " :ファイル形式が不正です。");
			return false;
		}
	}
}
