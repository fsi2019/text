package jp.co.fsi.nexticj.supporttool.sfdc.bean;

/**
 *
 * @author keinakamu
 *
 */
public class SettingSupportResultBean {

	private String orgName;
	private SettingStatus metadata;
	private SettingStatus customSetting;

	public enum SettingStatus {
		SUCCESS,		// 成功
		ERROR,			// エラー
		NOT_SET		// 未設定(※初期値)
	}

	/**
	 * コンストラクタ
	 */
	public SettingSupportResultBean() {
		this.orgName = "";
		this.metadata = SettingStatus.NOT_SET;
		this.customSetting = SettingStatus.NOT_SET;
	}

	/**
	 * @return orgName
	 */
	public String getOrgName() {
		return orgName;
	}

	/**
	 * @param orgName セットする orgName
	 */
	public void setOrgName(String orgName) {
		this.orgName = orgName;
	}

	/**
	 * @return metadata
	 */
	public SettingStatus getMetadata() {
		return metadata;
	}

	/**
	 * @param metadata セットする metadata
	 */
	public void setMetadata(SettingStatus metadata) {
		this.metadata = metadata;
	}

	/**
	 * @return customSetting
	 */
	public SettingStatus getCustomSetting() {
		return customSetting;
	}

	/**
	 * @param customSetting セットする customSetting
	 */
	public void setCustomSetting(SettingStatus customSetting) {
		this.customSetting = customSetting;
	};
}
