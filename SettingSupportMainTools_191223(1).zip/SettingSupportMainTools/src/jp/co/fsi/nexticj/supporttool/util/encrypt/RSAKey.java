package jp.co.fsi.nexticj.supporttool.util.encrypt;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.security.InvalidKeyException;
import java.security.Key;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.SecureRandom;
import java.security.Security;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;

/**
 * RSAキーを作成
 * @author keinakamu
 *
 */
public class RSAKey {

	/**
	 * RSAキーペアを作成する
	 * @return Base64エンコードされた公開鍵と暗号鍵
	 * @throws NoSuchPaddingException
	 * @throws NoSuchProviderException
	 * @throws NoSuchAlgorithmException
	 */
	public String[] createKeyPairAsBase64()
			throws NoSuchAlgorithmException, NoSuchProviderException, NoSuchPaddingException {
		String[] keyPair = new String[2];

		/**
		 * KeyPairを作成
		 */
		Security.addProvider(new org.bouncycastle.jce.provider.BouncyCastleProvider());
		KeyPairGenerator generator = KeyPairGenerator.getInstance("RSA", "BC");

		SecureRandom random = new SecureRandom();
		generator.initialize(2048, random);
		KeyPair pair = generator.generateKeyPair();

		/**
		 * KeyPairをBase64エンコードして返却
		 */
		keyPair[0] = encodeObjectAsBase64(pair.getPublic());
		keyPair[1] = encodeObjectAsBase64(pair.getPrivate());

		return keyPair;
	}

	/**
	 * 暗号化を行う
	 * @param data
	 * @param base64Key
	 * @return 暗号化されたデータ
	 * @throws IOException
	 * @throws NoSuchPaddingException
	 * @throws NoSuchProviderException
	 * @throws NoSuchAlgorithmException
	 * @throws InvalidKeyException
	 * @throws BadPaddingException
	 * @throws IllegalBlockSizeException
	 */
	public byte[] encryptByBase64Key(final byte[] data, final String base64Key)
			throws IOException, NoSuchAlgorithmException, NoSuchProviderException, NoSuchPaddingException,
			InvalidKeyException, IllegalBlockSizeException, BadPaddingException {

		List<byte[]> encList = new ArrayList<byte[]>();
		int encryptLength = 0;

		// 暗号化処理
		{
			int position = 0;
			while (position < data.length) {

				// 暗号化データ分割サイズを決定(16～255の間)
				final int random;
				{
					final int SIZE_MIN = 16;	// 最小分割値(1～254)
					final int SIZE_MAX = 255;	// 最大分割値(SIZE_MIN～255)
					Random rand = new Random();
					random = rand.nextInt(SIZE_MAX - SIZE_MIN) + SIZE_MIN;
					//System.out.println(random); // データ分割サイズ(デバッグ用)
				}

				// データ分割
				int len = position + random < data.length ? random : data.length - position;
				byte[] splitData = new byte[len];
				System.arraycopy(data, position, splitData, 0, len);
				position += len;

				// 暗号化
				Security.addProvider(new org.bouncycastle.jce.provider.BouncyCastleProvider());
				Key myKey = (Key) decodeObjectFromBase64(base64Key);
				Cipher cipher = Cipher.getInstance("RSA/None/NoPadding", "BC");
				cipher.init(Cipher.ENCRYPT_MODE, myKey, new SecureRandom());
				byte[] encrypt = cipher.doFinal(splitData);

				// 暗号化された配列を記憶
				encList.add(encrypt);
				encryptLength += encrypt.length;
			}
		}

		// 結合処理
		byte[] resData = new byte[encryptLength];
		{
			int position = 0;
			for (byte[] b : encList) {
				System.arraycopy(b, 0, resData, position, b.length);
				position += b.length;
			}
		}

		return resData;
	}

	/**
	 * 復号化を行う
	 * @param data
	 * @param base64Key
	 * @return 復号化されたデータ
	 * @throws IOException
	 * @throws InvalidKeyException
	 * @throws NoSuchPaddingException
	 * @throws NoSuchProviderException
	 * @throws NoSuchAlgorithmException
	 * @throws BadPaddingException
	 * @throws IllegalBlockSizeException
	 */
	public byte[] decryptBtBase64Key(final byte[] data, final String base64Key)
			throws IOException, InvalidKeyException, NoSuchAlgorithmException, NoSuchProviderException,
			NoSuchPaddingException, IllegalBlockSizeException, BadPaddingException {

		List<byte[]> decList = new ArrayList<byte[]>();
		int decryptLength = 0;

		// 復号化処理
		{
			int position = 0;
			while (position < data.length) {

				// データ分割
				final int DEC_LENGTH = 256;	// 復号化時のデータ分割サイズ(256固定)
				int len = position + DEC_LENGTH < data.length ? DEC_LENGTH : data.length - position;
				byte[] splitData = new byte[len];
				System.arraycopy(data, position, splitData, 0, len);
				position += len;

				// 復号化
				Security.addProvider(new org.bouncycastle.jce.provider.BouncyCastleProvider());
				Key myKey = (Key) decodeObjectFromBase64(base64Key);
				Cipher cipher = Cipher.getInstance("RSA/None/NoPadding", "BC");
				cipher.init(Cipher.DECRYPT_MODE, myKey, new SecureRandom());
				byte[] decrypt = cipher.doFinal(splitData);

				// 復号化された配列を記憶
				decList.add(decrypt);
				decryptLength += decrypt.length;
			}
		}

		// 結合処理
		byte[] resData = new byte[decryptLength];
		{
			int position = 0;
			for (byte[] b : decList) {
				System.arraycopy(b, 0, resData, position, b.length);
				position += b.length;
			}
		}

		return resData;
	}

	/**
	 * ObjectをBase64エンコード
	 * @param o
	 * @return エンコード結果
	 */
	private String encodeObjectAsBase64(Object o) {
		// 状況に応じてだが、今回はバイトを圧縮して少しでも小さなサイズを返す
		try (ByteArrayOutputStream byteos = new ByteArrayOutputStream();
				GZIPOutputStream gos = new GZIPOutputStream(byteos);) {
			try (ObjectOutputStream objos = new ObjectOutputStream(gos)) {
				objos.writeObject(o);
			}
			byte[] retObject = byteos.toByteArray();
			return Base64.getEncoder().encodeToString(retObject);
		} catch (IOException ex) {
			Logger.getLogger(RSAKey.class.getName()).log(Level.SEVERE, null, ex);
			return null;
		}
	}

	/**
	 * Base64エンコードをObjectに変換
	 * @param s
	 * @return
	 * @throws IOException
	 */
	private Object decodeObjectFromBase64(String s) throws IOException {
		byte[] bytes = Base64.getDecoder().decode(s);
		try (GZIPInputStream gis = new GZIPInputStream(new ByteArrayInputStream(bytes))) {
			return new ObjectInputStream(gis).readObject();
		} catch (ClassNotFoundException ex) {
			return null;
		}
	}
}
