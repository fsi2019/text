package jp.co.fsi.nexticj.supporttool.deploymeta;

public class LoginInfo {
	private String userId;
	private String passWord;
	private String orgName;
	private String isSandBox;
	private String version;

	/**
	 * コンストラクタ
	 */
	public LoginInfo() {
		this.userId = "";
		this.passWord = "";
		this.orgName = "";
		this.isSandBox = "";
		this.version = "";
	}
	/**
	 * userIdを取得します。
	 * @return userId
	 */
	public String getUserId() {
	    return userId;
	}
	/**
	 * userIdを設定します。
	 * @param userId userId
	 */
	public void setUserId(String userId) {
	    this.userId = userId;
	}
	/**
	 * passWordを取得します。
	 * @return passWord
	 */
	public String getPassWord() {
	    return passWord;
	}
	/**
	 * passWordを設定します。
	 * @param passWord passWord
	 */
	public void setPassWord(String passWord) {
	    this.passWord = passWord;
	}
	/**
	 * orgNameを取得します。
	 * @return orgName
	 */
	public String getOrgName() {
	    return orgName;
	}
	/**
	 * orgNameを設定します。
	 * @param orgName orgName
	 */
	public void setOrgName(String orgName) {
	    this.orgName = orgName;
	}
	/**
	 * isSandBoxを取得します。
	 * @return isSanBox
	 */
	public String getSandBox() {
	    return isSandBox;
	}
	/**
	 * isSandBoxを設定します。
	 * @param isSanBox isSanBox
	 */
	public void setSandBox(String isSanBox) {
	    this.isSandBox = isSanBox.toLowerCase();
	}
	/**
	 * versionを取得します。
	 * @return version
	 */
	public String getVersion() {
	    return version;
	}
	/**
	 * versionを設定します。
	 * @param version version
	 */
	public void setVersion(String version) {
	    this.version = version;
	}
}
