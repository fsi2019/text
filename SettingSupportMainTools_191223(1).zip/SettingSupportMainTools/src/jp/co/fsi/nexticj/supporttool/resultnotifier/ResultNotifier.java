package jp.co.fsi.nexticj.supporttool.resultnotifier;
import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.Map;

import jp.co.fsi.nexticj.supporttool.SettingSupportProperties;
import jp.co.fsi.nexticj.supporttool.sfdc.bean.SettingSupportResultBean;
import jp.co.fsi.nexticj.supporttool.sfdc.bean.SettingSupportResultBean.SettingStatus;
import jp.co.fsi.nexticj.supporttool.sfdc.webservice.SetSettingSupportResult;

/**
 * 配信後設定の結果通知クラス
 * @author keinakamu
 *
 */
public class ResultNotifier {

	/** 作業ディレクトリ */
	private final String CURRENT_DIR;

	/* リトライ設定 */
	private final static int RETRY_MAX_COUNT = 2;  // 接続エラー時のリトライ数, 0=リトライしない
	private final static int RETRY_WAIT_SEC = 5;   // 次のリトライまで待つ秒数

	// クラス変数
	private SetSettingSupportResult webservice;

	/**
	 * コンストラクタ
	 */
	public ResultNotifier() {
		CURRENT_DIR = System.getProperty("user.dir");
		this.webservice = new SetSettingSupportResult();
	}

	public boolean start() {

		// プロパティを取得
		SettingSupportProperties p = SettingSupportProperties.getInstance();

		// ユーザ情報を復号化
		String encryptoPath = "";
		try {
			encryptoPath = new File(CURRENT_DIR, p.getWsLoginIngo()).getCanonicalPath();
		} catch (IOException e) {
			System.out.println("[ERROR] ログイン情報ファイルパスが不正です。");
			return false;
		}

		DecryptoResultNotifierLoginInfo decrypto = new DecryptoResultNotifierLoginInfo(encryptoPath);
		if (!decrypto.start()) {
			System.out.println("[ERROR] ログイン情報の復号化に失敗しました。");
			return false;
		}

		// WebServiceに接続する
		webservice.setUserName(decrypto.getUsername());
		webservice.setPassword(decrypto.getPassword());
		webservice.setProxyHost(p.getProxyHost());
		webservice.setProxyPort(p.getProxyPort());

		// 実行,リトライ処理あり
		int retryCount = RETRY_MAX_COUNT;  // リトライ回数
		int wait = RETRY_WAIT_SEC;         // 次のリトライまでの待ち秒数
		try {
			while(true) {
				boolean result = webservice.execute();
				if (!result && retryCount > 0) {
					System.out.println("[INFO] "+ wait +"秒後にリトライします。");
					Thread.sleep(wait * 1000);
					retryCount--;
				} else {
					break;
				}
			}
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

		return true;
	}

	/**
	 * WebServiceに設定結果を送信する
	 * @return
	 */
	public boolean setMetaDeployResult(List<String> targetList, Map<String, Boolean> mapResult) {
		for(String orgName : targetList) {
			SettingSupportResultBean b = new SettingSupportResultBean();
			b.setOrgName(orgName);
			b.setMetadata(mapResult.get(orgName) ? SettingStatus.SUCCESS : SettingStatus.ERROR);
			webservice.upsertSendData(b);
		}
		return true;
	}
}
