package jp.co.fsi.nexticj.supporttool.deploymeta;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class FileOperation {
	//フォルダ作成
	public static void copyDir(String pathFrom,String pathTo) throws IOException {
		// 対象パス存在か
	    File targetFile = new File(pathTo);
	    if(!targetFile.exists()){
	        (new File(pathTo)).mkdirs();
	    }
	    // フォルダ配下取得
	    File[] file = (new File(pathFrom)).listFiles();
	    for (int i = 0; i < file.length; i++) {
	        if (file[i].isFile()) {
	            // ファイルコピー
	            copyFile(file[i],new File(pathTo + File.separator + file[i].getName()));
	        }
	        if (file[i].isDirectory()) {
	            // フォルダコピー
	            String sourceDir = pathFrom + File.separator + file[i].getName();
	            String targetDir = pathTo + File.separator + file[i].getName();
	            copyDir(sourceDir, targetDir);
	        }
	    }
	}
	// ファイルコピー
	public static void copyFile(File sourceFile,File targetFile) throws IOException{
	    // インプットストリーム
	    FileInputStream input = new FileInputStream(sourceFile);
	    BufferedInputStream inBuff=new BufferedInputStream(input);

	    // アウトプットストリーム
	    FileOutputStream output = new FileOutputStream(targetFile);
	    BufferedOutputStream outBuff=new BufferedOutputStream(output);

	    // バイト
	    byte[] b = new byte[1024 * 5];
	    int len;
	    while ((len =inBuff.read(b)) != -1) {
	        outBuff.write(b, 0, len);
	    }
	    // フラッシュ
	    outBuff.flush();

	    //クローズ
	    inBuff.close();
	    outBuff.close();
	    output.close();
	    input.close();
	}
}
