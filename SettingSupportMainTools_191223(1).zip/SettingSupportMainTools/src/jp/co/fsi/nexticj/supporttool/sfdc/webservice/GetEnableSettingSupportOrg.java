package jp.co.fsi.nexticj.supporttool.sfdc.webservice;

import java.util.LinkedHashMap;
import java.util.Map;

import com.sforce.soap.SettingSupportInfoWebService.SoapConnection;
import com.sforce.ws.ConnectionException;

import jp.co.fsi.nexticj.supporttool.sfdc.login.LoginUtilPartner;

public class GetEnableSettingSupportOrg {

	// 接続情報
	private String userName;
	private String password;
	private String proxyHost;
	private String proxyPort;

	// WebService結果
	private Map<String, String> orgMap;

	/**
	 * @return userName
	 */
	public String getUserName() {
		return userName;
	}

	/**
	 * @param userName セットする userName
	 */
	public void setUserName(String userName) {
		this.userName = userName;
	}

	/**
	 * @param password セットする password
	 */
	public void setPassword(String password) {
		this.password = password;
	}

	/**
	 * @return proxyHost
	 */
	public String getProxyHost() {
		return proxyHost;
	}

	/**
	 * @param proxyHost セットする proxyHost
	 */
	public void setProxyHost(String proxyHost) {
		this.proxyHost = proxyHost;
	}

	/**
	 * @return proxyPort
	 */
	public String getProxyPort() {
		return proxyPort;
	}

	/**
	 * @param proxyPort セットする proxyPort
	 */
	public void setProxyPort(String proxyPort) {
		this.proxyPort = proxyPort;
	}

	/**
	 * @return orgMap
	 */
	public Map<String, String> getOrgMap() {
		return orgMap;
	}

	/**
	 * コンストラクタ
	 */
	public GetEnableSettingSupportOrg() {
		this.userName = "";
		this.password = "";
		this.proxyHost = "";
		this.proxyPort = "";
		this.orgMap = new LinkedHashMap<String, String>();
	}

	/**
	 * WebServiceに接続する
	 * @return 成功/失敗
	 */
	public boolean execute() {

		LoginUtilPartner partner = new LoginUtilPartner();
		partner.setLoginInfo(userName, password);
		if (proxyHost.isEmpty() && proxyPort.isEmpty()) {
			System.out.println("[INFO] Salesforceに直接ログインします。");
		} else {
			try {
				int portNum = Integer.parseInt(proxyPort);
				partner.setProxy(proxyHost, portNum);
				System.out.println("[INFO] Salesforceにプロキシを使用してログインします。");
			} catch (NumberFormatException e) {
				System.out.println("[ERROR] プロキシポート番号は整数で入力してください。");
				return false;
			}
		}

		// Salesforce ログイン
		if (partner.login()) {
			System.out.println("[INFO] Salesforceにログイン成功しました。");
		} else {
			System.out.println("[ERROR] Salesforceにログインできませんでした。");
			return false;
		}

		// WebService接続
		try {
			SoapConnection sconnection = partner.getSoapConnection();

			// コールして結果を出力
			String[] res = sconnection.getEnableSettingSupportOrg();
			System.out.println("[INFO] *** 取得結果 ***");
			int idx = 1;
			for (String s : res) {
				// 結果を格納
				String data[] = s.split(":");
				if (data.length == 2) {
					if (orgMap.containsKey(data[0])) {
						System.out.println("[WARN] " + idx + "| " + s + " は既に登録されています。");
					} else {
						try {
							@SuppressWarnings("unused")
							double d = Double.parseDouble(data[1]);
							orgMap.put(data[0], data[1]);
							System.out.println("[INFO] " + idx + "| " + s);
						} catch (NumberFormatException e) {
							System.out.println("[WARN] " + idx + "| " + s + " バージョン番号が不正です。");
						}
					}
				}
				else if(data.length == 0) {
					System.out.println("[INFO] 配信可能な組織は0件です。");
				}
				idx++;
			}
			System.out.println("[INFO] ****************");

		} catch (ConnectionException e) {
			e.printStackTrace();
			System.out.println("[ERROR] SalesforceのgetEnableSettingSupportOrgにアクセスできません。");
			return false;
		}

		return true;
	}
}
