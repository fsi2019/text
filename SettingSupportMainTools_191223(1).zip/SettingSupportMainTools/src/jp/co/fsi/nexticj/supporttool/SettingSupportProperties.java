package jp.co.fsi.nexticj.supporttool;

import java.io.File;
import java.io.IOException;
import java.net.URISyntaxException;

import jp.co.fsi.nexticj.supporttool.util.file.PropertyReader;



/**
 * deploymeta.confの設定を格納
 * @author keinakamu
 *
 */
public class SettingSupportProperties {

	// 設定ファイル名
	private final static String CONF_FILENAME = "settingsupport.conf";

	// 定数
	private final static String PROPERTY_PROXYHOST = "proxy_host";
	private final static String PROPERTY_PROXYPORT = "proxy_port";
	private final static String PROPERTY_LOGININFO = "logininfo";
	private final static String PROPERTY_THREADMAX = "thread_max";
	private final static String PROPERTY_WSLOGININFO="webservice_logininfo";

	// エラー判定
	private boolean isReadError;

	// プロパティ設定
	private String proxyHost;
	private String proxyPort;
	private String loginInfo;
	private String threadmax;
	private String wsLoginIngo;

	/**
	 * @return isReadError
	 */
	public boolean isReadError() {
		return isReadError;
	}

	/**
	 * @return proxyHost
	 */
	public String getProxyHost() {
		return proxyHost;
	}

	public String getThreadmax() {
		return threadmax;
	}

	/**
	 * @return proxyPort
	 */
	public String getProxyPort() {
		return proxyPort;
	}

	/**
	 * @return loginInfo
	 */
	public String getLoginInfo() {
		return loginInfo;
	}

	/**
	 * @return wsLoginIngo
	 */
	public String getWsLoginIngo() {
		return wsLoginIngo;
	}

	/**
	 * コンストラクタ
	 * @throws URISyntaxException
	 * @throws IOException
	 */
	private SettingSupportProperties() {
		try {
			String path = new File(System.getProperty("user.dir"),CONF_FILENAME).getCanonicalPath();
			PropertyReader reader = new PropertyReader(path);
			if(reader.isExistsFile()) {
				this.proxyHost = reader.getProperty(PROPERTY_PROXYHOST, "");
				this.proxyPort = reader.getProperty(PROPERTY_PROXYPORT, "");
				this.loginInfo = reader.getProperty(PROPERTY_LOGININFO);
			    this.threadmax = reader.getProperty(PROPERTY_THREADMAX);
			    this.wsLoginIngo = reader.getProperty(PROPERTY_WSLOGININFO);
				this.isReadError = false;
			} else {
				this.isReadError = true;
				System.out.println("[ERROR] プロパティファイルが読み込めません。: " + path );
			}
		} catch (IOException e) {
			this.isReadError = true;
			e.printStackTrace();
			System.out.println("[ERROR] プロパティファイルの読み込みでエラーが発生しました。");
		}
	}

	/**
	 * インスタンスを返す
	 * @return インスタンス
	 */
	public static SettingSupportProperties getInstance() {
		return ConfigInstanceHolder.INSTANCE;
	}

	/**
	 * インスタンスを保持する内部クラス
	 * @author keinakamu
	 *
	 */
    public static class ConfigInstanceHolder {
        /** 唯一のインスタンス */
        private static final SettingSupportProperties INSTANCE = new SettingSupportProperties();
    }
}
