package jp.co.fsi.nexticj.supporttool.sfdc.login;

/**
 * ログイン処理の抽象クラス
 *
 * @author keinakamu
 *
 */
abstract class AbstractLoginUtil {

	private String username;
	private String password;
	private boolean isSandbox;
	private String apiVersion;

	//プロキシ設定
	private boolean useProxy;
	private String proxyHost;
	private int proxyPort;

	final static String LOGIN_DEFAULT = "https://login.salesforce.com/services/Soap/";
	final static String LOGIN_SANDBOX = "https://test.salesforce.com/services/Soap/";

	/**
	 * コンストラクタ
	 */
	public AbstractLoginUtil() {
		this.username = "";
		this.password = "";
		this.isSandbox = false;
		this.apiVersion = "39.0";
		this.useProxy = false;
		this.proxyHost = "";
		this.proxyPort = 0;
	}

	/**
	 * @return username
	 */
	public String getUsername() {
		return username;
	}

	/**
	 * @return password
	 */
	public String getPassword() {
		return password;
	}

	/**
	 * @return isSandbox
	 */
	public boolean isSandbox() {
		return isSandbox;
	}

	/**
	 * @param isSandbox
	 *            セットする isSandbox
	 */
	public void setSandbox(boolean isSandbox) {
		this.isSandbox = isSandbox;
	}

	/**
	 * @return apiVersion
	 */
	public String getApiVersion() {
		return apiVersion;
	}

	/**
	 * @param apiVersion
	 *            セットする apiVersion
	 */
	public void setApiVersion(String apiVersion) {
		this.apiVersion = apiVersion;
	}

	/**
	 * @return useProxy
	 */
	public boolean isUseProxy() {
		return useProxy;
	}

	/**
	 * @return proxyHost
	 */
	public String getProxyHost() {
		return proxyHost;
	}

	/**
	 * @return proxyPort
	 */
	public int getProxyPort() {
		return proxyPort;
	}

	/**
	 * ログイン情報を設定する
	 *
	 * @param username
	 *            ユーザ名
	 * @param password
	 *            パスワード
	 */
	public void setLoginInfo(String username, String password) {
		this.username = username;
		this.password = password;
	}

	/**
	 * ログイン情報を設定する
	 *
	 * @param username
	 *            ユーザ名
	 * @param password
	 *            パスワード
	 * @param isSandbox
	 *            サンドボックス環境
	 */
	public void setLoginInfo(String username, String password, boolean isSandbox) {
		this.username = username;
		this.password = password;
		this.isSandbox = isSandbox;
	}

	/**
	 * ログイン情報を設定する
	 *
	 * @param username
	 *            ユーザ名
	 * @param password
	 *            パスワード
	 * @param apiVersion
	 *            APIバージョン
	 * @param isSandbox
	 *            サンドボックス環境
	 */
	public void setLoginInfo(String username, String password, String apiVersion, boolean isSandbox) {
		this.username = username;
		this.password = password;
		this.apiVersion = apiVersion;
		this.isSandbox = isSandbox;
	}

	/**
	 * プロキシ設定を行う
	 * @param host ホスト名
	 * @param port ポート番号
	 */
	public void setProxy(String host, int port) {
		this.useProxy = true;
		this.proxyHost = host;
		this.proxyPort = port;
	}

	/**
	 * ログイン処理
	 *
	 * @return true=成功/false=失敗
	 */
	public abstract boolean login();
}
