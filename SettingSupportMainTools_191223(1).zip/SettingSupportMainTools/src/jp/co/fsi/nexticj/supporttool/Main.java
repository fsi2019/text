package jp.co.fsi.nexticj.supporttool;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import jp.co.fsi.nexticj.supporttool.deploymeta.DecryptoLoginInfo;
import jp.co.fsi.nexticj.supporttool.deploymeta.ExecuteDeploy;
import jp.co.fsi.nexticj.supporttool.deploymeta.FileOperation;
import jp.co.fsi.nexticj.supporttool.deploymeta.LoginInfo;
public class Main {

	// ステータスの定数
	private static final int STATUS_OK = 0;
	private static final int STATUS_NG = 1;

	/**
	 * メインメソッド
	 * @param args
	 */
	public static void main(String [] args) {
		int status = STATUS_NG;
		System.out.println("[INFO] 処理を開始します。");

		try {

			// workフォルダ取得
			System.out.println("[INFO] WORKフォルダを取得。");
			String workFolder = args[0];
			if (!workFolder.endsWith("/")) {
				workFolder = workFolder + "/";
			}
			System.out.println("[INFO] WORKフォルダを取得しました。");

			// プロパティの取得と確認
			System.out.println("[INFO] プロパティファイルを取得。");
			if(SettingSupportProperties.getInstance().isReadError()) {
				System.out.println("[ERROR] プロパティファイルが取得できません。");
				return;
			}
			System.out.println("[INFO] プロパティファイルを取得しました。");

			// ログイン情報を取得
			System.out.println("[INFO] ログイン情報を取得。");
			Map<String, LoginInfo> loginMap = getLoginInfo(workFolder);
			System.out.println("[INFO] ログイン情報を取得しました。");

			// 組織情報ファイルから、組織取得
			System.out.println("[INFO] 組織情報を取得。");
			Map<String, LoginInfo> mapOrgInfo = new HashMap<String, LoginInfo>();
			List<String> orgList = new ArrayList<String>();

			ArrayList<String> list = readFromTextFile(workFolder + args[1]);
			for(String orgInfo : list) {
				orgList.add(CopyDeployData(orgInfo, workFolder, loginMap, mapOrgInfo));
			}
			System.out.println("[INFO] 組織情報を取得しました。");

			// デプロイ実行
			System.out.println("[INFO] デプロイを実行。");
			ExecuteDeploy exe = new ExecuteDeploy();
			exe.Deploy(orgList, mapOrgInfo, workFolder, args[2]);
			System.out.println("[INFO] デプロイが完了しました。");

			// ステータスを成功にする
			status = STATUS_OK;

		} catch (IOException e) {
			e.printStackTrace();
			System.out.println("[ERROR] 例外エラーが発生しました。- IOException");

		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("[ERROR] 例外エラーが発生しました。" );

		} finally {
			if (status == STATUS_OK) {
				System.out.println("[INFO] 処理が終了しました。" );
			} else {
				System.out.println("[ERROR] 処理が中断しました。" );
			}
			System.exit(status);
		}
	}
	/**
	 * 組織情報読み込み
	 * @param pathname
	 * @return
	 * @throws IOException
	 */
	private static ArrayList<String> readFromTextFile(String path) throws IOException{
		File file = new File(path);

		ArrayList<String> strArray = new ArrayList<String>();
	    InputStreamReader reader = new InputStreamReader(new FileInputStream(file), "UTF-8");
	    BufferedReader br = new BufferedReader(reader);
	    String line = "";
	    line = br.readLine();
	    while(line != null) {
	        strArray.add(line);
	        line = br.readLine();
	    }
	    br.close();
	    return strArray;
	}

	/**
	 * デプロイ用データ用意
	 * @param orgStr
	 * @param workFolder
	 * @param parentFolder
	 * @throws IOException
	 */
	private static String CopyDeployData(String orgStr, String workFolder, Map<String, LoginInfo> mapLoginInfo,
			Map<String, LoginInfo> mapOrgInfo) throws IOException{
		// 親フォルダ取得
		String parentFolder = workFolder.substring(0,
				workFolder.substring(0, workFolder.length() - 1).lastIndexOf("/") + 1);
		String toolFolder = parentFolder + "tool/";
		String dataFolder = parentFolder + "data/";
		// 組織情報取得
		String[] orgInfo = orgStr.split(",");
		// 組織のフォルダ
		String orgFolder = orgInfo[0]+"_"+orgInfo[1];

		// -----------データフォルダ----------
		// 共通メタデータ
		String comMeta = dataFolder + orgInfo[1] + "/common/metadata";
		// 組織飲メタデータ
		String orgMeta = dataFolder + orgInfo[1] + "/" + orgInfo[0] + "/metadata";
		// -----------データフォルダ----------

		// 組織のフォルダ作成
		String orgPath = workFolder + orgFolder;
		File targetFile = new File(orgPath);
		if(!targetFile.exists()){
	        (new File(orgPath)).mkdirs();
	    }
		// メタデータコピー
		String metaPath = orgPath + "/metadata";
		FileOperation.copyDir(comMeta, metaPath);
		FileOperation.copyDir(orgMeta, metaPath);

		// buildファイルコピー
		File srcBuild = new File(toolFolder + "/migration_tool/template_build.xml");
		File targetBuild = new File(workFolder + orgFolder + "/build.xml");
		FileOperation.copyFile(srcBuild, targetBuild);
//		System.out.println(mapLoginInfo);
//		System.out.println(orgInfo[0]);

		LoginInfo loginInfo = mapLoginInfo.get(orgInfo[0]);
//		System.out.println(loginInfo);
		loginInfo.setVersion(orgInfo[1]);
		mapOrgInfo.put(orgInfo[0], loginInfo);

		return orgInfo[0];
	}

	private static Map<String, LoginInfo> getLoginInfo(String workFolder) throws IOException {
		// 親フォルダ取得
		String parentFolder = workFolder.substring(0,
				workFolder.substring(0, workFolder.length() - 1).lastIndexOf("/") + 1);
		String toolFolder = parentFolder + "tool/";

		// ログイン情報ファイルから取得
		Map<String, LoginInfo> loginMap = new HashMap<String, LoginInfo>();

		// 暗号化ファイルの復号
		//List<String> loginInfoList = readFromTextFile(toolFolder + "migration_tool/loginInfo.bin");
		SettingSupportProperties prop = SettingSupportProperties.getInstance();
		DecryptoLoginInfo decrypt = new DecryptoLoginInfo(
				new File(toolFolder + "migration_tool", prop.getLoginInfo()).getCanonicalPath());
		if (!decrypt.start()) {
			System.out.println("[ERROR] ログイン情報の復号化に失敗しました。");
			return new HashMap<String, LoginInfo>();
		}
		List<String> loginInfoList = decrypt.getOrgList();
		List<String> orgList = new ArrayList<String>();


		// Mapに格納
		for(Integer i = 0;i<loginInfoList.size();i++) {
			orgList =  Arrays.asList(loginInfoList.get(i).split(","));
			LoginInfo temp = new LoginInfo();
			temp.setOrgName(orgList.get(0));
			temp.setUserId(orgList.get(1));
			temp.setPassWord(orgList.get(2));
			temp.setSandBox(orgList.get(3));
			loginMap.put(temp.getOrgName(), temp);
		}

		return loginMap;
	}
}
