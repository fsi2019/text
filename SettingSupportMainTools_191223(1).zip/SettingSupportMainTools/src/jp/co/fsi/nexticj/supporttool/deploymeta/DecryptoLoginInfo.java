package jp.co.fsi.nexticj.supporttool.deploymeta;

import java.io.IOException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;

import jp.co.fsi.nexticj.supporttool.util.encrypt.RSAKey;
import jp.co.fsi.nexticj.supporttool.util.encrypt.SecretForTool;
import jp.co.fsi.nexticj.supporttool.util.file.FileIoBytes;

/**
 * ログイン情報を復号化する
 * @author keinakamu
 *
 */
public class DecryptoLoginInfo {

	// クラス変数
	private String encryptoFilePath;
	private List<String> orgList;

	// secret_forTool.txt の文字列を設定
	private final static String DATA = "IRzcJFUQBFUQBFUQBtkVWFmVCRlV4hWOKVUQJlkSHxWWFNXURFFVGVEaDJXSrhUUJ1UVBR1UGJURJpETDl0L35kSzZHT0cUQpF3dxVkSsFHSCNEMLtkSVlWQIp1R5FHTDdnVpFHSTt0R5h2VRFkVMJTVwFmRydkQyoGcysybPp1Mwt2NjtSO1UDO4Njeyt2Lu12dZBjQIFUQJtGSzdXaSB1QHh1SXlVeCF0Zip0T45WT2lleRFVSmVzbtd2SCFUbNFkUpR0ZkVUWJhmSnFUVNF0ctJ2U0N3VDVUTpJ0ZKZzd0c2LLdUWypmbXdmQENnShVUQzEERCl2dvd2MERTePhGcnFVeFVVU3REenBFMQV0YPl1drJEauV0cRl2Y4dUUCNmSFRkWNBVU4pXUKRzNQRjMxl0ZRVmQJRDRXZXOHdGZ2oWdBhmc0c3Uz8GS0U1drdGM49SNZN3bIV0d0AlVvcWbsNlZmRTYyQDV1klUzVGRhF0QBFUeIZUeWt2Q3hldSVHT0YWOFtibN5GWxc0aygUNZdHS1I2dQ1meXJWSIFjVltUTsFWWn1UcBh1QXt2SF5WSS10bEZFSB5UQMdWdKlUUP1GMSF0cRN0Z4Ima3lEOwgWaCtUUJ90VUF0aNJDTCFVVJRUVSl0aFF2ZLRjQZh1QHhERtFUNEJUWYF1bSJVSBt0Z2MkUONzSVx0Z5sWTM9WdnVVVhN0YMJ3cqp0VCljRr12QnRUarc0LmJ3NuVDRRNUQsh2QlxGOv1GTQdTUxEFdrQ3aER1bJN0UIV2bSVEUykWdPZjextUdqdzcGR0NolHO50UaQhVcFNWdZdTN6Z1YaVjaHRmb1N3apNGcyxmd3Q0cjRFaD9mVut2K44kSLNTZzJUcxhFSzlVT3cDOvx2Ka5EWyljbolmb3dkYLtkSJd1aPJ3SrlTdzETaWNDOwlUOIJTYwUHS5I1YL5WdJ1mNhRDTuNlR1UnUnJGb4pWc3YldqtmaiR2L4VjZhJmb2RGO2dURrRTVBxWUMNVYVdFbmdlT4U1bp9mc4dzKNFGRKZHZUFlWrRle492YvEDWzdjTkdWaLplQoV2Vxk0UJpGWJ9kYRJVVOV3VhZFZzVkbzpVWXVDOltyRXdkNoVGMaJmd3ETalVWcYZnRoRDd2MHMpplUmZHeyJUSuJ0NaFkUxM0Zx8SSNZmRxdldMFUe2BnUidUTDdzcUtmTPdVNrAzLSJjcW5Wc0IHdOJjW2lmR0RjWPNzLidkerkWO1gzUVVjVSBVOkhET6x0KZRXOMd3d6dVeTBDOnNjMxhTYv0mQwNjTVRTcvYEVuZ1N0cVe0YzSlpWcURjeLd1ZEJGblhGbZV2KwEDdr1GdM9Sa1llejtybSR2NTdDSyd2T0REMIRnTvBDOP5WYJZnbzEzYZpGWrhzToV2U3E3ZIZUbT5UbpVlVZtkU5MTdj1EWUtidZhjTwRXe1x2a5MTa0ZWWxsyLERHc2lXSnZjdkhVe6ZnaQJ1LygmSaJ3Urk1LxpkMzVXRHR1YGZjMv50csxWc6FnUKVnd0Z1M5o2SllmSplTY1RUbsZVNhd3KUpkVMVDbYJGTxIHUtRzZGZzN5E0TptGUjNjZ2hVZrgVdLN1T1QXZ3gXZNRXdy82bCxWMX9CeSVVMKp3TEBVNrMFerN2VEFHZTtEZOVXbiVHcyZ3Vv50UQJGe2JjdZVTeuhXOvtmNoRDTWlzK0IlYRVESIJjWmVEVilHcSdka2o2Q1FFNhNDVyl1bQlDV5FVeOhzVRFTY4cmM0tkWzZ3TOpUc3t2KuJjSThHcwpWeOhGWHh3U5Eja0YFRyg2UWR2QwgEOv1UVmJHZWtmdzJlSzkGd1QWcr5mWXhlbv0kQMtCM2ETZMtEch1Wa6V2TvR2UUpVO2N0d3oFUlRnblZ3TudWOwklVrJVUvlXeWlEZDh3QrsCcUlVTChlcWlXV5VFeiNTRmdlarhHb2klcthzblNWcllkTUBjazM0b5UFRuNGN18yM3ZWUuFXNIBlU1E3NPRzLtRlUVJ2arRDOTJWOp1EZrZ2QSdDbrVTO1IUc1ZTV5N0aQBlT3RVZ5hFRhpVe2RXcKx0RulXcppFZvhXN2cEcxIkaS92RzFEcPlUdyEjYMVlVopmM2Bjc1h1TkRnbrJjNNpVZXhFelNjSK12d2R2TodnYk9SO0UmVF12KitSOSBnd0hGTZ5Gbql1VspVbkBHbVtSZsBXYqtEbJZlN4JzRFFzQw4mNr8EeLlkZrcGM1o2akdjcwFHMrlEa2QzZzw0QwkXd5RmcyVza6RzKiVnTVtmMvdTZuJ2S0dVMxp1cLZFelFjZIN0TEhGOupVNrkVcOd1M0gXavZHOsdTc1VESQJWQ4dmW0YzdoFzUYd2TpdkNLFVZsxmZzMDeIZ3V5dTa4UWNxYneGJjV5FmQmx2NURGZ1EDRygWY58URx0mYv12SHFzUv52V21WVXF2QWB1RYpFaIVXZ4YFNEJXcjt0MyhEZ5MWNFhXc5kHc0J3aWRFeYllWvRnYUlGMzMlN0NUTMVTZiFlUDFjNmtybSZ3bMBFSvZXO0UkV1NVZlRmUZZmMEZWZRxWeyVET1J0SiVzazsmcTNjWzdFN1lXea9GTQNzTaF2MzAXMxhHTuF3VxUFb14WbXxUT25WVMRmT1oXM6t0ciJWYypXd11kezk0Mj9yRm9Ud3V2SvNDWyZGSTJHcjV3d1hUV0UmVzsmbRVUcwcnNKZDd6pGT5IDWodlNUJENxNHcP1Ua2EWUVxmd5gHNpp3SFd0S1U1V2ADNvZmMlB3VplGS1h2MDVlat90cXV3N0dWUXpFZIl3d25EZrh2VWNFMP9ycvhEM5tEOsF0KFhWaU92U5oHU4d1LNBVRnZGcpp3RKFDdMhDVlx0KCp0Z4tCMthmQ3FUQ";

	/**
	 * @return encryptoFilePath
	 */
	public String getEncryptoFilePath() {
		return encryptoFilePath;
	}

	/**
	 * @return orgList
	 */
	public List<String> getOrgList() {
		return orgList;
	}

	/**
	 * コンストラクタ
	 * @param keyPath 復号化されたファイルパス
	 */
	public DecryptoLoginInfo(String encryptoFilePath) {
		this.encryptoFilePath = encryptoFilePath;
		this.orgList = new ArrayList<String>();
	}

	/**
	 * 復号化処理
	 * @return 成功/失敗
	 */
	public boolean start() {
		try {
			RSAKey rsaKey = new RSAKey();
			FileIoBytes ioBytes = new FileIoBytes(encryptoFilePath);
			final String plainText = new String(
					rsaKey.decryptBtBase64Key(ioBytes.readAll(), SecretForTool.decrypt(DATA)), "UTF-8");
			orgList = Arrays.asList(plainText.split("\n"));
			return true;

		} catch (InvalidKeyException | NoSuchAlgorithmException | NoSuchProviderException | NoSuchPaddingException
				| IllegalBlockSizeException | BadPaddingException | IOException e) {
			e.printStackTrace();
			return false;
		} catch (IllegalArgumentException e) {
			System.out.println("[ERROR] このファイルはログイン情報ファイルではないか、鍵が間違っています。");
			return false;
		}
	}
}
