package jp.co.fsi.nexticj.supporttool.util.file;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.stream.Collectors;

/**
 * ファイルを文字列で読み書きするクラス
 * @author keinakamu
 *
 */
public class FileIoString {

	private static final String CHAR_ENCODE = "UTF-8";
	private final String path;

	/**
	 * @return path
	 */
	public String getPath() {
		return path;
	}

	/**
	 * コンストラクタ
	 * @param filePath ファイルパス
	 */
	public FileIoString(String filePath) {
		this.path = filePath;
	}

	/**
	 * 書き込み
	 * @param inputData データ
	 * @throws IOException
	 */
	public void writeAll(String inputData) throws IOException {
        try (FileOutputStream fos = new FileOutputStream(path);) {
        	try (OutputStreamWriter osw = new OutputStreamWriter(fos,CHAR_ENCODE);) {
                osw.write(inputData);
                osw.close();
        	}
        	fos.close();
        }
	}

	/**
	 * 読み込み
	 * @return データ
	 * @throws IOException
	 */
	public String readAll() throws IOException {
	    return Files.lines(Paths.get(path), Charset.forName(CHAR_ENCODE))
	        .collect(Collectors.joining(System.getProperty("line.separator")));
	}
}
