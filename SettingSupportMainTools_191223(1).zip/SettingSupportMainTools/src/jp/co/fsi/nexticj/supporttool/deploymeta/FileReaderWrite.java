package jp.co.fsi.nexticj.supporttool.deploymeta;

import java.io.File;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.stream.Collectors;

/**
 * Byte型のファイル読み込み・書き込み
 * @author keinakamu
 *
 */
class FileReaderWrite {

    private Path path;

    /**
     *　コンストラクタ
     * @param filePath
     */
    public FileReaderWrite(String filePath) {
        path = new File(filePath).toPath();
    }

    /**
     *　書き込み
     * @param inputData　データ
     * @throws IOException
     */
    public void write(byte[] inputData) throws IOException {
        Files.write(path, inputData);
    }

    /**
     *　読み込み
     * @return　データ
     * @throws IOException
     */
    public byte[] read() throws IOException {
        return Files.readAllBytes(path);
    }

    /**
     *　CSV読み込み
     * @return　データ
     * @throws IOException
     */
    public String readAll() throws IOException {
        return Files.lines(path, Charset.forName("UTF-8"))
                    .collect(Collectors.joining(System.getProperty("line.separator")));
    }
}

