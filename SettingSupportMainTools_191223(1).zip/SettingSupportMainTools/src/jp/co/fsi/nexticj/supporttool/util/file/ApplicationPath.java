package jp.co.fsi.nexticj.supporttool.util.file;

import java.io.File;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.CodeSource;
import java.security.ProtectionDomain;

public class ApplicationPath {

	private ApplicationPath() {}

    /**
     * JARファイルの場所を取得
     * @param cls クラス
     * @return ファイルパス
     * @throws URISyntaxException
     */
	public static Path getApplicationPath(Class<?> cls) throws URISyntaxException {
		ProtectionDomain pd = cls.getProtectionDomain();
		CodeSource cs = pd.getCodeSource();
		URL location = cs.getLocation();
		URI uri = location.toURI();
		Path path = Paths.get(uri);
		return path;
	}

	/**
	 * JARファイルの保存先を取得
	 * @param cls クラス
	 * @return ファイルパス
	 * @throws URISyntaxException
	 */
	public static Path getParentPath(Class<?> cls) throws URISyntaxException {
		String path = getApplicationPath(cls).toString();
		File f = new File(path);
		return Paths.get(f.getParent());
	}
}
