


public class test {

	static String  name= "zhang";
	static long a[] = new long[10];
	static final String finaltest = "final";
	public static void main (String [] args) {
		/**name = null;
		System.out.println("ss");
		assert(name.equals(null));
		System.out.println("name null");
		Integer i5 = 127;
		Integer ii5 = new Integer(127);
		System.out.println(i5 == ii5);

		int a ='A';
		System.out.println(a);
		System.out.println(100.0 * 0.6);
		int i=1;
		int j;
		j = i++;

		System.out.println("i="+i);
		System.out.println("j="+j);
		j = ++i;
		System.out.println("i="+i);
		System.out.println("j="+j);
		System.out.println(a[0]);
		Parent p = new Parent();
		System.out.println(finaltest);
		byte zero1 = '0';
		System.out.println(zero1);

		FileInputStream in;
		try {
			in = new FileInputStream("C:\\Users\\860616028\\Desktop\\test\\file.dat");
			in.skip(9);
			int c = in.read();
			System.out.println(c);
		} catch (Exception e) {
			// TODO 自動生成された catch ブロック
			e.printStackTrace();
		}
		Integer index = 0;
		switch (index) {
		case 1 :
			System.out.println('1');
			break;
		case 2 :
			System.out.println('2');
			break;
	    default :
				System.out.println('3');

		}**/
		String str = "83W251004-00.pdf";
		System.out.println(str.contains("."));
		String s = getGaikanzuName(str,".");
		System.out.println(s);
		String t = getGaikanzuName(s,"-");
		System.out.println(t);


	}

	/**
	* getGaikanzuName
	*
	* @param: strFullGaikanzu
	* @param: splitChar
	* @return: String
	* @created: 2017/10/17 Ksvc nhvinh
	* @modified:
	**/
	private static String getGaikanzuName(String strFullGaikanzu, String splitChar){
		String[] listGaikanzu = strFullGaikanzu.split(splitChar);
		return listGaikanzu[0];
	}



}


class Parent{
	public void method1() {
	System.out.println("Parent's method1()");
	         }
	         public void method2() {
	  System.out.println("Parent's method2()");
	  method1();
	         }
	}
	class Child extends Parent{

	        public void method1(int i) {
	System.out.println("Child's method1()");
	        }
	public static void main(String args[]){
	Child p = new Child();
	p.method2();
	}
	}




